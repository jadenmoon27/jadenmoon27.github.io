# Main-table display sources

This directory contains LaTeX sources for the three main manuscript tables:

- `table1_population_structure.tex`
- `table2_principal_results.tex`
- `table3_simulation_summary.tex`

These files reproduce the table layout and frozen values reported in the manuscript. They are not data-processing or statistical-computation scripts. They cannot regenerate participant-level predictions, real-data confidence intervals, or simulation rates.
