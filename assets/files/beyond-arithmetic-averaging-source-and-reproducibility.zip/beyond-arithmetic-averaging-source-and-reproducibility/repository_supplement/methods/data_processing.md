# MAIBO analysis transformations

The analysis retained every structurally eligible participant and segment in the retained archive. It did not resample, resegment, or reapply the provider-described band-pass filter.

## Implemented transformations

- Signal arrays and HR labels were converted to 32-bit floating-point values.
- Array shape and finiteness were checked before fitting.
- Signal-summary features were computed from the supplied arrays before model standardization.
- For every model fit, each channel's mean and standard deviation were estimated across all samples in the model's training rows.
- Standard deviations were floored at `1e-6`.
- Training-derived normalization statistics were applied to held-out rows.
- The supplied scalar `HR` value was used as the prediction target.
- Participant, posture, record, and segment identifiers were used for alignment, folds, weighting, and evaluation.
- The primary estimand retained posture-specific observed populations; the 46 complete-three-posture participants were used only for a separate sensitivity analysis.

## Weighting used for prediction-model training

For segment `t` from participant `i` in posture `r`, the unnormalized training weight was

`1 / (3 * N_r * n_{i,r})`,

where `N_r` is the number of training participants observed in posture `r` and `n_{i,r}` is that participant's number of training segments in the posture. Weights were normalized to mean one within each fit. This mirrors the equal-posture participant-macro evaluation target.
