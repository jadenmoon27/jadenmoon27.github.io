# Eligibility and candidate-prediction alignment

A participant file was structurally eligible only when all required signal arrays, the supplied HR reference, posture, participant identifier, and segment identifiers were present and readable. All four arrays had to match the expected shape and contain finite values, and the supplied HR reference had to be finite.

All 1,086 retained participant files passed these checks. No segment was removed because of an invalid signal array or non-finite reference.

The four candidate estimates were aligned by participant, posture, and segment identifier before any procedure value was calculated. Every retained segment therefore had:

1. a side-1 estimate;
2. a side-2 estimate;
3. their arithmetic mean;
4. a learned bilateral-fusion estimate;
5. one supplied HR reference.

This is a fully observed candidate-loss setting. The label-informed oracle is consequently a retrospective benchmark over these four recorded estimates, not an estimate over unobserved models or unrestricted routing policies.
