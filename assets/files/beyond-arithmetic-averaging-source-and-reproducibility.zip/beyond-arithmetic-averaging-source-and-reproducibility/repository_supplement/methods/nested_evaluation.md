# Participant-disjoint nested evaluation

## Fold construction

Participants were assigned to five outer folds. Within each posture-availability pattern, a deterministic hash-based ordering under seed `20260806` was followed by round-robin allocation. Four inner folds were generated analogously within each outer-training partition. The construction preserved participant disjointness and approximately balanced participant counts and posture-availability patterns.

No outer-test segment contributed to:

- normalization statistics;
- prediction-model fitting;
- prediction-model hyperparameter or epoch selection;
- gain-model fitting;
- switching-margin selection;
- policy-library selection.

## Prediction-model tuning

For each prediction-model grid item, models were trained on three inner folds and scored on the fourth. The selection criterion was the arithmetic mean of equal-posture participant-macro MAE for the side-1, side-2, and fusion heads. Ties followed fixed grid order. The outer refit epoch was the rounded median of the best epochs across the four inner folds.

## Outer-training out-of-fold predictions

For every outer-training segment, an inner model generated candidate predictions used to construct routing features and gain labels. Each inner participant was excluded from the individual model fit that generated its prediction. However, model settings and refit epoch had already been chosen using validation outcomes across all four inner folds. The out-of-fold predictions are therefore inputs for fitting and selection, not independent estimates of the final tuned pipeline.

The same stitched inner evidence selected model variants, margins, and the policy-library member. The effect of these upstream dependencies on which policy was selected was not separately evaluated.

## Outer-test evaluation

After all settings were locked, three prediction models were fitted on all outer-training participants, one for each fixed seed, using outer-training normalization. Their outer-test candidate predictions were passed to the locked audited router and training-selected policy. Only outer-test losses contributed to the reported MAIBO results.

The five outer-test partitions were stitched after fold-local prediction and selection. Participant-cluster bootstrap intervals condition on these fixed folds, predictions, hyperparameters, router settings, and selected policies.
