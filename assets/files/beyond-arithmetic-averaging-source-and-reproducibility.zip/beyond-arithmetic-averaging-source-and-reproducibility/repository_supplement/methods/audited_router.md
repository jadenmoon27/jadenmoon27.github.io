# Audited lower-quantile router

## Gain labels

For each alternative candidate `a` in `{side 1, side 2, bilateral fusion}`, the development gain label was

`abs(reference - arithmetic_mean) - abs(reference - candidate_a)`.

Positive gain means that the candidate had lower absolute error than arithmetic averaging. Gain labels were constructed only from training-participant out-of-fold predictions and supplied training references.

## Model

The audited router fit one histogram-gradient-boosting quantile regressor for each alternative candidate. Each regressor estimated the conditional `q = 0.20` quantile of gain using the complete 38-feature vector and the participant/posture-aligned training weights.

Fixed regressor settings:

- 200 boosting iterations;
- learning rate 0.05;
- at most 15 leaf nodes;
- at least 50 samples per leaf;
- L2 regularization 1.0;
- no internal early stopping.

## Deterministic routing rule

The router selected the candidate with the largest predicted gain only when that value was strictly greater than the selected margin. Otherwise it returned the arithmetic-mean baseline. Ties followed the fixed candidate order: arithmetic mean, side 1, side 2, bilateral fusion.

## Margin selection

Within each outer-training partition, the margin was selected from `{0, 0.25, 0.50, 0.75, 1.00}` BPM using inner out-of-fold equal-posture participant-macro MAE. A candidate margin also had to satisfy the operational condition that no posture's development MAE deteriorated by more than 0.50 BPM relative to arithmetic averaging. After rounding MAE to 12 decimal places, ties favored the larger margin and then the lower nonbaseline selection rate. If no margin met the condition, the procedure returned arithmetic averaging for every test segment.

The 0.50-BPM values are engineering thresholds, not clinical safety margins. The lower-quantile construction was intended to favor candidates whose predicted gain remained positive under a pessimistic conditional summary. It is not conformal and carries no distribution-free risk guarantee.
