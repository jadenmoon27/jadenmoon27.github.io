# Aligned-candidate evaluation setting

**Status:** Source-derived technical supplement for Stage 5.  
**Main-paper dependency:** The final manuscript does not require this file to understand the principal evaluation protocol.

## Scope

The MAIBO analysis uses an aligned-candidate setting. For every retained ten-second segment, the record contains:

- a supplied reference heart rate;
- one estimate from each sensor side;
- the arithmetic mean of the two unilateral estimates;
- one learned bilateral-fusion estimate; and
- the estimate selected by each frozen routing procedure.

All compared procedures are therefore evaluated on the same held-out segments. Their paired error differences are observed directly; the analysis does not estimate unobserved outcomes for candidates that were not selected.

## Candidate procedures and fitted instances

The candidate set fixes four procedure identities: side 1, side 2, arithmetic averaging, and learned bilateral fusion. Each outer fold may fit its own model parameters using that fold's training participants. The identity of a candidate procedure is shared across folds, but the fitted parameter values need not be.

A frozen routing policy maps declared prediction-time features to one of the four candidates. The label-informed oracle instead uses the supplied held-out reference heart rate to select the lowest-error candidate for each segment. Its choices are retrospective and restricted to the four recorded candidates.

## Structural requirements

The reported participant-disjoint comparisons require:

1. participant identifiers that support separated training and test partitions;
2. aligned reference values and predictions from every candidate on each retained test segment;
3. observed support for every reported posture; and
4. feasible outer and inner participant partitions for model fitting and policy selection.

If these records are unavailable, the corresponding held-out comparison cannot be reconstructed. A log containing only a policy's final returned estimate is insufficient because it omits the unselected candidate estimates needed for the paired audit and the label-informed oracle.

## Boundary relative to logged-action evaluation

This is a fully observed candidate-comparison setting, not a contextual-bandit or logged-action setting in which the outcomes of unchosen actions are missing. The availability of all four candidate predictions permits direct paired comparisons, but it does not make the candidate set exhaustive, the oracle deployable, or the results representative of untested fusion architectures.
