# Candidate prediction model

## Candidate estimates

For each fixed prediction seed, the network produced:

- side-1 HR from two side-1 PPG channels;
- side-2 HR from two side-2 PPG channels;
- the arithmetic mean of the two unilateral outputs;
- learned bilateral fusion from both learned side representations.

Each candidate's final estimate was the arithmetic mean across three fixed prediction seeds: `20260806`, `20260817`, and `20260829`.

## Shared side encoder

Each side entered the same shared-weight one-dimensional residual encoder as a `2 x 1,000` array.

| Component | Specification |
|---|---|
| Stem | `Conv1d(2,32,7)` + `GroupNorm(8)` + GELU |
| Residual stages | Four two-block stages with widths `32/64/128/256` |
| Stage strides | First block strides `1/2/2/2` |
| Residual-block kernel | 5 |
| Pooling | Global average pooling |
| Side representation | 256 dimensions |

## Prediction heads

| Head | Specification |
|---|---|
| Unilateral head | `Linear(256,128)` + GELU + `Dropout(0.10)` + `Linear(128,1)`; shared across sides |
| Fusion input | `[z1, z2, abs(z1-z2), z1*z2]`, 1,024 dimensions |
| Fusion head | `Linear(1024,256)` + GELU + `Dropout(0.10)` + `Linear(256,1)` |

The fusion comparator is therefore feature-level bilateral fusion, not an average of final unilateral estimates and not a raw-channel early-fusion architecture.

## Training and tuning

| Item | Specification |
|---|---|
| Loss | Mean of three Smooth-L1 losses for side 1, side 2, and fusion; 5-BPM transition |
| Weighting | Equal-posture participant-macro-aligned row weights |
| Optimizer | AdamW |
| Gradient clipping | Norm 5 |
| Mixed precision | Not used |
| Learning-rate grid | `{3e-4, 1e-3}` |
| Weight-decay grid | `{1e-4, 1e-3}` |
| Batch-size grid | `{128, 256}` |
| Inner tuning | Four participant-disjoint inner folds; minimize mean equal-posture participant-macro MAE across the three prediction heads |
| Epoch selection | Maximum 100 epochs, patience 10; earliest epoch breaks ties |
| Outer refit epoch | Half-up rounded median of the four selected inner-fold epochs |

Hyperparameters were selected using the first fixed seed. Final inner out-of-fold and outer-test predictions used all three seeds.
