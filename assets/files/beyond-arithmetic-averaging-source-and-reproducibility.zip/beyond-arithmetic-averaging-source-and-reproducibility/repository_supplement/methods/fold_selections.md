# Outer-fold composition and selected procedures

All selected prediction-model batch sizes were 128. The training-selected policy varied by outer fold, as permitted by the prespecified fold-local selection pipeline.

| Fold | Test participants | Test segments | Learning rate | Weight decay | Refit epochs | Selected procedure |
|---:|---:|---:|---:|---:|---:|---|
| 0 | 221 | 11,932 | `1e-3` | `1e-4` | 31 | Gradient-boosted mean gain, uniform segment weighting, zero margin |
| 1 | 217 | 11,890 | `3e-4` | `1e-4` | 33 | Random-forest mean gain |
| 2 | 217 | 11,104 | `3e-4` | `1e-4` | 29 | Random-forest mean gain |
| 3 | 216 | 11,687 | `3e-4` | `1e-3` | 37 | Random-forest mean gain |
| 4 | 215 | 11,184 | `3e-4` | `1e-4` | 39 | Equal-posture gradient-boosted mean gain with an inner-selected margin |

Random-forest mean-gain routing was selected in three folds. Gradient-boosted mean-gain procedures were selected in two. This pattern describes one stitched nested evaluation and is not five independent replications.
