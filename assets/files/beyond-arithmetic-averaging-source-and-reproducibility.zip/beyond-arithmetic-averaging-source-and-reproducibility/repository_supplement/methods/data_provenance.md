# MAIBO data provenance and retained analytical partition

## Provider-reported resource

The Multi-posture Asymmetry-aware Intelligent Bilateral Observation (MAIBO) resource is described as containing synchronized bilateral ring photoplethysmography (PPG) recorded during lying, sitting, and standing. The provider reports:

- 1,810 participants split into training, validation, and test partitions of 1,086, 362, and 362 participants;
- 57,797 segments in the reported training partition;
- 100-Hz acquisition;
- fourth-order 0.5-15-Hz Butterworth band-pass filtering applied forward and backward;
- nonoverlapping 10-second windows;
- per-channel z-score normalization within each window;
- a session-wise cuff-monitor `HR` reference;
- exclusion of records without a reference measurement or time-matched PPG.

These are provider-reported procedures. They were not independently reconstructed from original device logs.

## Retained archive observed by this analysis

The retained archive contains:

| Population | Participant identifiers | Segments |
|---|---:|---:|
| Entire analytical partition | 1,086 | 57,797 |
| Lying | 622 | 19,109 |
| Sitting | 961 | 29,028 |
| Standing | 356 | 9,660 |
| All three postures | 46 | not separately counted |

Posture-specific participant sets overlap. Availability patterns were: lying only 91; lying+sitting 479; lying+sitting+standing 46; lying+standing 6; sitting only 160; sitting+standing 276; standing only 28.

Each record supplied:

- four arrays in the field order `ppg_GA_1`, `ppg_GB_1`, `ppg_GA_2`, `ppg_GB_2`;
- one scalar `HR` label;
- `posture`;
- `bp_idx` and `ppg_idx` identifiers;
- participant identity from the file identifier.

Each signal record had shape `4 x 1,000`. The separately supplied filtered-waveform and DC-component fields were not used.

## Interpretation boundary

Matching the provider's published training-partition totals is consistent with, but does not independently verify, exact participant membership, curation history, representativeness, or the rule that assigned a session-wise reference HR value to each segment. Reported model errors quantify agreement with the supplied labels rather than independently reconstructed beat-to-beat HR.
