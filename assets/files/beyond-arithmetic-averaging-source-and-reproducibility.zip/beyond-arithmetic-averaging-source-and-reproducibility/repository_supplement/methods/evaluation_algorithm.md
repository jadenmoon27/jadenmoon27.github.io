# Participant-disjoint evaluation algorithm

This document preserves the execution sequence formerly given as appendix pseudocode. The main manuscript contains the information needed to understand the analysis; this file provides the step-by-step implementation contract.

1. **Validate the evaluation structure.** Confirm participant identifiers, aligned candidate estimates and supplied references on the same segments, support for each reported posture, and feasible participant-disjoint folds. Stop any comparison whose required structure is absent.
2. **Create outer participant folds.** Keep all segments and postures from one participant in the same outer fold.
3. **Create inner participant folds within each outer-training split.** Generate the out-of-fold candidate predictions, losses, gain labels, and prediction-time features needed for router fitting and policy selection.
4. **Fit and select without outer-test outcomes.** Fit the candidate models, router components, and comparison-library procedures. Select the audited-router margin and training-selected policy using only the corresponding outer-training evidence, applying the declared tie rules.
5. **Lock the outer-fold procedure.** Freeze every model, hyperparameter, margin, feature set, and policy choice before inspecting outer-test losses.
6. **Evaluate once on outer-test participants.** Apply the locked procedures to the corresponding held-out participants. Do not refit, reselect, filter, or tune using their outcomes.
7. **Stitch held-out predictions.** Concatenate the five outer-test partitions so that every retained participant is scored only by procedures developed without that participant's outcomes.
8. **Compute the common estimand.** Score arithmetic averaging, fixed learned bilateral fusion, the audited lower-quantile router, the training-selected policy, and the label-informed oracle using the equal-posture participant-macro MAE defined in the manuscript.
9. **Resample participants for conditional uncertainty.** Draw participants with replacement, retain all of their observed postures and segments, and use the same resample for every procedure. Keep folds, predictions, fitted settings, and selections fixed.
10. **Report the continuous evidence and analysis status.** Preserve primary, post hoc, robustness, descriptive, unresolved, and unavailable states. Do not force an unsupported directional conclusion.

The inner out-of-fold table supports fitting and selection; it is not an independent estimate of the final pipeline because upstream hyperparameter decisions may use the other inner folds. The final held-out evidence comes from the outer-test participants. The participant bootstrap characterizes the stored held-out predictions and does not include retraining, retuning, or repeated policy selection.
