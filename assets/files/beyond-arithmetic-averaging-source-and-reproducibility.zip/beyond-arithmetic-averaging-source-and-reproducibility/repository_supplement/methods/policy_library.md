# Training-selected policy library

The training-selected policy was chosen separately within each outer-training partition from ten deployment-compatible procedures. The audited lower-quantile router itself was not eligible.

| Policy family | Specification |
|---|---|
| Arithmetic mean only | Always return the arithmetic-mean baseline. |
| Training-selected fixed candidate | Select one of arithmetic mean, side 1, side 2, or bilateral fusion using minimum training-fold out-of-fold equal-posture MAE. |
| Ridge mean-gain | One multi-output ridge model for the three mean gains; weighted training-only standardization; `alpha` in `{0.1, 10}`; zero margin. |
| Random-forest mean-gain | One 300-tree multi-output forest; either depth 4/minimum leaf 8 or depth 8/minimum leaf 4; zero margin. |
| Gradient-boosted mean-gain | Three histogram-gradient-boosting mean regressors using the audited router's tree settings; uniform segment weights; zero margin. |
| Participant-balanced lower-quantile gain | Lower-`q = 0.20` regressors with participant-balanced weights and an inner-selected margin. |
| Equal-posture mean-gain with margin | Mean-gain gradient boosting with equal-posture participant weights and an inner-selected margin. |
| Lower-quantile gain without positive margin | Audited-router family using all features and a fixed zero margin. |
| Lower-quantile gain without signal summaries | Audited-router family using prediction-derived features only and an inner-selected margin. |
| Fixed learned bilateral fusion | Always return bilateral fusion. |

## Selection procedure

For learned gain models, inner predictions were produced by fitting on three of four inner folds and predicting the fourth. Constant procedures required no gain fit. Ridge and random-forest variants, switching margins where applicable, and the library member were selected using stitched inner scores. Selection minimized equal-posture participant-macro MAE rounded to 12 decimal places, followed by the specified variant and margin tie rules and then fixed library order.

After selection, learned components were refit on all outer-training out-of-fold rows and applied to the outer-test features. The selected procedure is a fold-local algorithm-selection pipeline rather than one router chosen from pooled outer-test performance.
