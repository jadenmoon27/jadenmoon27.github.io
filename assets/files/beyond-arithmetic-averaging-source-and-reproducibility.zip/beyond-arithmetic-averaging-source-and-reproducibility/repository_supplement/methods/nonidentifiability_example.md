# Why router-versus-average performance is insufficient

This note preserves the mathematical construction formerly placed in the manuscript appendix. It is an explanatory example, not an additional experiment.

Consider one evaluation condition, two equally weighted segments per participant, and two candidate procedures: an arithmetic-mean baseline and an alternative. The audited router always returns the baseline. The comparison library contains one policy: use the alternative when a binary feature equals 1 and use the baseline otherwise.

In **System A**, both candidates have absolute loss 1 on both segments. The baseline, fixed alternative, audited router, selected policy, and label-informed oracle therefore all have the same mean loss.

In **System B**, the baseline still has loss 1 on both segments, while the alternative has loss 2 when the feature equals 0 and loss 0 when the feature equals 1. The audited router and the always-alternative fixed procedure still average to loss 1, but the training-selected policy and the label-informed oracle average to loss 0.5.

The audited router has the same reduction relative to arithmetic averaging in both systems, yet the performance of the training-selected policy and oracle differs. Therefore, router-versus-average performance alone cannot identify either the value achieved by another development-selected procedure or the remaining candidate-restricted hindsight headroom.

A second constant-loss example makes the fixed-comparator point. Let the baseline and audited-router candidates have losses 2 and 1. The router improves on the baseline by 1 whether a specified fixed alternative has loss 0.5 or 1.5, but the router is worse than the fixed alternative in the first system and better in the second. The same router-versus-average gain is therefore compatible with opposite conclusions against a stronger fixed comparator.

These constructions establish non-identifiability of the requested attribution from the weak comparison alone. They do not identify a causal engineering mechanism or rank unrestricted model classes.
