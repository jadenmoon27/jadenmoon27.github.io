# Methods supplement

This folder preserves technical specifications removed from the final application-facing PDF. The main paper remains self-contained for its central claims.

## Files

- `formal_setting.md` — generic aligned-candidate evaluation setting retained from Stage 5.
- `data_provenance.md` — provider-reported resource, retained archive, posture availability, and provenance boundaries.
- `data_processing.md` — implemented transformations, normalization, and training weights.
- `eligibility.md` — structural eligibility and alignment checks.
- `model_architecture.md` — candidate prediction network, training settings, tuning grid, and fixed seeds.
- `features.md` — all 38 routing features and excluded prediction-time information.
- `audited_router.md` — gain labels, lower-quantile model, deterministic rule, and margin selection.
- `policy_library.md` — complete ten-procedure library and selection rule.
- `nested_evaluation.md` — outer/inner fold construction, tuning dependencies, and held-out evaluation.
- `fold_selections.md` — outer-fold composition, prediction settings, and selected policy family.

## Availability boundary

These files document the methods represented in the manuscript source. The project does not currently include the original executable MAIBO training/inference implementation, trained model states, participant-level prediction records, or verified full training commands. The documentation must not be represented as end-to-end reproducibility of model training or interval recalculation.
