# Routing features

The full routing vector contains 38 prediction-time features: 12 prediction-derived features and 26 signal-summary features.

## Prediction-derived features (12)

1. seed-averaged arithmetic-mean prediction;
2. seed-averaged side-1 prediction;
3. seed-averaged side-2 prediction;
4. seed-averaged bilateral-fusion prediction;
5. absolute side-1/side-2 disagreement;
6. absolute fusion/arithmetic-mean difference;
7. range across the four candidate predictions;
8. variance across the four candidate predictions;
9-12. across-seed dispersion for each candidate prediction.

## Signal-summary features (26)

The first six families were computed separately for each of the four supplied channels. Two additional features captured matched-channel bilateral correlations.

| Feature family | Count | Definition |
|---|---:|---|
| Finite fraction | 4 | Fraction of finite samples. Under the all-finite eligibility rule, these coordinates equal one. |
| Clipping fraction | 4 | Repeated-minimum and repeated-maximum counts, each minus one, divided by segment length; a constant channel's shared extremum is counted once. |
| Robust amplitude | 4 | 95th sample percentile minus 5th sample percentile. |
| First-difference energy | 4 | Mean squared difference between adjacent samples. |
| Spectral concentration | 4 | Largest non-DC real-FFT power divided by total non-DC power after mean centering; zero when total power is zero. |
| Spectral peak ambiguity | 4 | Second-largest non-DC real-FFT power divided by largest non-DC power; zero when largest power is zero. |
| Bilateral correlation | 2 | Zero-lag correlation for matched channels; zero when the product of centered root-mean-square scales is at most `1e-12`. |

These signal summaries are study-defined proxies, not externally validated signal-quality scores or calibrated correctness probabilities.

## Excluded prediction-time information

The routers did not receive:

- supplied or held-out HR;
- participant identity;
- posture;
- demographic attributes;
- blood-pressure variables;
- future segments;
- filtered or DC signal fields;
- finger identifiers.

Participant and posture identifiers were retained only for fold construction, weighting, evaluation, and training-time margin selection where specified.
