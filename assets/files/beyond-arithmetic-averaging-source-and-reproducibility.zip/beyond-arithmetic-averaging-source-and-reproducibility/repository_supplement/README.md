# Repository supplement

**Release status:** exact artifact inventory locked for the final-preprint revision. This supplement preserves technical detail removed from the manuscript and states explicitly which computations the release can and cannot reproduce.

The manuscript is designed to stand alone. This folder provides methods documentation, secondary result records, simulation specifications, display-layer sources, and release manifests. It is not an executable end-to-end replication package.

## Stable structure

- `methods/` — source-derived documentation of data handling, candidate estimators, fixed learned bilateral fusion, router features and objective, policy library, fold selections, and participant-disjoint evaluation.
- `simulation/` — source-derived known-truth design, data-generating specification, profiles, interval construction, endpoints, headline results, boundary cases, ablations, and an explicit availability statement.
- `results/` — detailed robustness, gap-accounting, feature/library sensitivity, fixed-fusion comparisons, practical-error summaries, and participant-level heterogeneity.
- `tables/` — LaTeX display sources for the three main tables. These files reproduce table layout from frozen reported values; they do not recompute the values.
- `figures/` — display-generation materials. The current release includes a self-contained Figure 1 renderer using frozen reported values and visual tokens.
- `manifests/` — release inventory, source tree, and SHA-256 manifests.
- `reproducibility/` — concise crosswalk explaining the supported and unsupported reproduction levels.

## Exact availability inventory

| Artifact category | Status | Location or source | What it supports | What it does not support |
|---|---|---|---|---|
| Public MAIBO data | Available externally | Zenodo DOI `10.5281/zenodo.19440421` | Access to the provider-released MAIBO Version V1 data | The data are not redistributed here; this release does not independently verify provider provenance or reference assignment |
| Manuscript source | Included | Project root: `main.tex`, `ref.bib`, `neurips_2026.sty` | Clean manuscript compilation | Recalculation of empirical results |
| Methods documentation | Included | `methods/` | Inspection of the declared architecture, features, policy library, folds, and evaluation design | Executable preprocessing, training, or inference |
| MAIBO training code | Not included | — | — | End-to-end model fitting or hyperparameter tuning |
| MAIBO inference code | Not included | — | — | Regeneration of participant-level candidate predictions |
| Trained model states | Not included | — | — | Reproducing the stored predictions from model checkpoints |
| Participant-level candidate predictions | Not included | — | — | Recalculation of real-data estimates, paired contrasts, or bootstrap intervals |
| Reference-HR arrays | Not included in this release | Obtain source data from the provider | External inspection through the public dataset | Local interval recalculation from this package alone |
| Simulation specification | Included | `simulation/` | Inspection of the designed conditions, profiles, endpoints, and reported aggregate outcomes | Executing the 21,600 repetitions |
| Executable simulation code | Not included | — | — | Independent recomputation of simulation rates |
| Repetition-level simulation records and bootstrap arrays | Not included | — | — | Recounting or auditing rates from raw simulation outputs |
| Main-table LaTeX sources | Included | `tables/` | Display regeneration from frozen values | Numerical recomputation from raw or participant-level records |
| Table-generation scripts | Not included | — | — | Automated regeneration of table values |
| Figure 1 generation code | Included | `figures/figure2/` | Regeneration of Figure 1 from frozen JSON values and visual tokens | Recalculation of point estimates or confidence intervals |
| Workflow-figure source | Not included | Design deferred and omitted from this release | — | Regeneration of a development-prediction-audit diagram |
| Integrity manifests | Included | `manifests/` and project-root `MANIFEST.sha256` | File-level integrity checking | Scientific validation |
| Institutional determination letter | Not included | Private institutional record | Manuscript ethics statement is based on the verified letter | Its absence has no bearing on computational reproduction |

## Supported reproduction levels

The release supports:

1. compiling the manuscript from the included LaTeX and BibTeX sources;
2. regenerating the three main tables as displays from their frozen LaTeX values;
3. regenerating Figure 1 from its frozen JSON inputs and visual tokens;
4. inspecting the declared MAIBO methods, secondary analyses, and known-truth simulation specification;
5. verifying file integrity through the supplied manifests.

## Unsupported reproduction levels

The release does not support:

1. MAIBO preprocessing, model retraining, tuning, or inference;
2. regeneration of participant-level candidate predictions;
3. recalculation of MAIBO estimates or participant-cluster confidence intervals;
4. execution of the known-truth simulation or independent recomputation of its reported rates;
5. independent verification of the supplied reference-HR assignment;
6. clinical, external, or cross-device validation.

## Interpretation rule

Successful manuscript compilation or display regeneration verifies only that the included source renders the frozen reported content. It does not reproduce model training, uncertainty estimation, the simulation experiment, or independent scientific validation.
