# Aggregate simulation results

## Headline endpoints

| Endpoint | Marginal percentile | Max-standardized |
|---|---:|---:|
| Joint coverage over 24 quantities | 73.93% (15,968/21,600) | 93.62% (20,221/21,600) |
| Any incorrect supported conclusion | 2.27% (490/21,600) | 0.45% (98/21,600) |
| Unresolved overall output | 5.65% (2,441/43,200) | 6.86% (2,965/43,200) |
| False prespecified-policy domain support | 0.95% (114/12,000) | 0.28% (34/12,000) |
| Adverse prespecified-policy domain detection | 93.00% (7,812/8,400) | 85.69% (7,198/8,400) |

Under marginal percentile intervals, coverage pooled across feature views within each of the 12 quantity types ranged from 94.41% to 97.80% (43,200 feature-view outputs per quantity).

## Joint coverage by test size under max-standardized intervals

- `N = 60`: 91.63%.
- `N = 200`: 94.25%.
- `N = 1000`: 94.97%.

## Joint coverage by design stratum

| Stratum | Marginal | Max-standardized |
|---|---:|---:|
| Complete synthetic-domain observation | 75.25% | 93.75% |
| MCAR incomplete observation | 72.36% | 93.52% |
| Rare-shock stress | 74.88% | 93.46% |

Incorrect-supported-conclusion rates for those strata were 1.84%, 2.05%, and 4.83% under marginal intervals, versus 0.40%, 0.38%, and 1.00% under max-standardized intervals.

Adverse selected-policy domains were detected in 7,152/7,200 (99.33%) eligible outputs with marginal intervals and 7,092/7,200 (98.50%) with max-standardized intervals.

These rates describe the prespecified finite grid. They do not establish exact 95% simultaneous coverage or universal error, power, or detection guarantees.
