# Data-generating process

Let `d` index one of three synthetic domains, `i` a participant, and `t` an opportunity. The candidate set contained an arithmetic default `a0`, a fixed procedure `aF`, and two alternative procedures `a1` and `a2`.

A latent state `Z_idt` took values `-1` and `+1` with equal probability. Participant shocks `U_i,F`, `U_i,1`, and `U_i,2` were independent across actions and participants and shared across a participant's synthetic domains and opportunities. Opportunity shocks `E_idt,F`, `E_idt,1`, and `E_idt,2` were independent Rademacher variables.

Gains relative to the default were:

```text
g_F = f_d + sigma_p U_i,F + sigma_e E_idt,F

g_1 = b_d + a_d Z_idt + sigma_p U_i,1 + sigma_e E_idt,1

g_2 = b_d - a_d Z_idt + sigma_p U_i,2 + sigma_e E_idt,2

g_0 = 0
```

Synthetic absolute losses were:

```text
loss(a0) = 4
loss(a)  = 4 - g_a, for a != a0
```

Every profile kept losses positive. Invalid parameterizations were rejected rather than clipped. The units are BPM-scaled synthetic loss differences for interpretation; they are not clinically validated heart-rate effects. Unlike MAIBO, the generator does not require the default estimate to equal the arithmetic mean of the alternatives or enforce the absolute-loss constraints that such predictions would imply.

## Cues

Two observed binary cues, `X1` and `X2`, were noisy measurements of `Z`:

```text
Pr(X_k = Z | d)  = q_k,d
Pr(X_k = -Z | d) = 1 - q_k,d
```

Cue errors were conditionally independent of gain shocks given the latent state.

## Participant-shock distributions

The main grid used symmetric `-1/+1` participant shocks. Four designated profiles were repeated under the bounded rare-shock law:

```text
U = -sqrt(10) with probability 0.05
U = 0         with probability 0.90
U = +sqrt(10) with probability 0.05
```

Both shock distributions have mean zero and variance one. The rare-shock setting is a bounded contamination stress, not an unbounded heavy-tail model.
