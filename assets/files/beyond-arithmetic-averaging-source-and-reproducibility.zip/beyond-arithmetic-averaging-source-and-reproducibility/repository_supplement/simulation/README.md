# Known-truth simulation supplement

**Migration status:** Stage 8 source-derived documentation complete.

The final preprint contains the simulation question, design scale, interval procedures, endpoint definitions, and four headline outcomes. This folder preserves the technical specifications removed from the PDF.

## Files

- `design.md` — sample structure, condition grid, pairing, missingness, and random-stream specification.
- `data_generating_process.md` — synthetic gains, losses, cues, and participant-shock distributions.
- `policies_and_selection.md` — finite policy library, restricted/expanded feature views, and independent development selection.
- `reference_truth.md` — analytic population references and candidate-restricted oracle calculation.
- `profiles/README.md` and `profiles/profiles.json` — all 16 prespecified profiles and the four profiles repeated under rare shocks.
- `inference.md` — participant-cluster bootstrap and marginal/max-standardized intervals.
- `endpoints.md` — operational thresholds, endpoint definitions, and denominators.
- `results.md` — headline and additional aggregate results.
- `boundary_cases.md` — conflict and decision-boundary behavior.
- `ablations.md` — point-only, interval-withholding, point-screen, selection-regret, and design limitations.
- `availability.md` — exact artifact boundary for this working project.

## Scope

These materials document a scoring-rule study with analytically known population values. They do not simulate photoplethysmography waveforms, validate MAIBO data or models, or provide external replication of the MAIBO performance ordering.

## Artifact boundary

The current Overleaf project does not contain the executable simulation implementation, `STUDY_FREEZE.json`, the recorded master-seed value, generated repetition-level records, or a verified command that regenerates the reported results. The documentation below is source-derived and auditable, but it is not an executable release. No missing artifact has been reconstructed or implied to be available.
