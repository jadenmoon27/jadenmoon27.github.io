# Prespecified simulation profiles

The main grid contains 16 profiles: eight clear/conflict profiles and eight boundary profiles. Scalar parameters apply to all three synthetic domains; arrays are ordered `(D1, D2, D3)`. Every profile uses `sigma_p = sigma_e`.

The operational overall tolerance is `tau = 0.10`; the synthetic-domain margin is `m = -0.25`. These are analysis thresholds, not clinical thresholds.

The machine-readable values are in `profiles.json`.

Four profiles were repeated under the bounded rare-shock participant distribution at each of the three test sizes under complete synthetic-domain observation:

- opportunity unobserved;
- overall gain with an adverse prespecified-policy domain;
- domain at the operational margin;
- realization difference at the operational tolerance.

These repetitions produce the 12 stress conditions.
