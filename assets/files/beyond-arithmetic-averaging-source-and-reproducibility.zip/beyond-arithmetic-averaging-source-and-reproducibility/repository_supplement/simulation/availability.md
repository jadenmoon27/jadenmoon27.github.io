# Simulation artifact availability

## Present in this project

- source-derived design, data-generating, policy, truth, profile, inference, endpoint, result, boundary, and ablation documentation;
- a machine-readable JSON representation of the 16 profile parameter tables and rare-shock profile names;
- the final preprint table values and controlling claim ledger.

## Not present in this project

- executable simulation code;
- `STUDY_FREEZE.json`;
- the recorded master-seed value;
- generated repetition-level records;
- bootstrap replicate arrays;
- executable commands verified to reproduce the reported rates.

Stage 14 lists these artifacts as unavailable in the manuscript and release inventory. The documentation here must not be described as executable code or as an independently reproducible simulation release.
