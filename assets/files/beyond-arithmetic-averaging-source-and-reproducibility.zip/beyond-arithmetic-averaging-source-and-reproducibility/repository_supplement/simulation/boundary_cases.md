# Conflict and boundary behavior

## Policy and synthetic-domain conflicts

- In the profile with positive overall prespecified-policy value and one adverse prespecified-policy domain, both procedures reported overall realization and adverse-domain evidence in all 3,600 relevant paired-feature evaluations.
- In the policy-specific conflict profile, prespecified-policy domain non-deterioration was supported in all 2,400 relevant evaluations while an adverse selected-policy domain was detected in all 1,200 applicable evaluations.

These results show that a synthetic-domain conclusion for one policy does not overwrite the overall output or transfer automatically to another policy.

## Boundary results

| Profile/event | Marginal percentile | Max-standardized |
|---|---:|---:|
| True domain value -0.30: adverse upper-bound evidence | 98.00% (2,352/2,400) | 95.50% (2,292/2,400) |
| True domain value -0.25: false strict non-deterioration support at boundary | 3.17% (114/3,600) | 0.94% (34/3,600) |
| True domain value -0.20: non-deterioration support | 98.75% (2,370/2,400) | 95.08% (2,282/2,400) |
| Overall difference 0.06: realization output | 99.08% (1,189/1,200) | 97.00% (1,164/1,200) |
| Overall difference 0.10: unresolved output | 94.11% (1,694/1,800) | 98.83% (1,779/1,800) |
| Overall difference 0.14: under-realization output | 95.17% (1,142/1,200) | 86.33% (1,036/1,200) |

Equality to the domain margin does not satisfy strict non-deterioration and is not strict adversity. These are designed frequencies, not universal power or error guarantees.
