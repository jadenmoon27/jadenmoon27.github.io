# Interval procedures

## Participant-cluster bootstrap

Each repetition used 999 valid multinomial participant-cluster bootstrap draws from the test participants. A sampled participant retained all observed synthetic domains and opportunities. Domain denominators and the equal-domain participant-macro quantity were recomputed in every draw. Identical bootstrap weights were applied to both feature views and all comparisons.

Inference required at least two observed test participants per synthetic domain. A draw with an empty domain denominator was replaced. The development-selected policy remained fixed within a repetition; selection variability appears across independent repetitions rather than inside that repetition's interval.

## Marginal percentile intervals

The primary marginal procedure formed separate 95% participant-cluster percentile intervals with linear interpolation. It did not claim 5% familywise error control for the combined conclusion rule.

## Max-standardized simultaneous intervals

The comparison procedure used the maximum standardized bootstrap deviation over 24 coordinates:

- six overall quantities;
- three domain-specific values for the prespecified policy;
- three domain-specific values for the selected policy;
- each reported under the restricted and expanded feature views.

For coordinate `j`, with estimate `theta_hat_j`, bootstrap standard deviation `s_hat_j`, and bootstrap replicate `theta_hat_j^(b)`, the bootstrap maximum was:

```text
M^(b) = max_j |theta_hat_j^(b) - theta_hat_j| / s_hat_j
```

The common critical value was the empirical 95th percentile of the bootstrap maxima, and coordinate `j` received:

```text
theta_hat_j +/- c_0.95 * s_hat_j
```

Coordinates with bootstrap standard deviation at or below `1e-12` contributed zero to the maximum and retained zero radius. This is a maximum-standardized-deviation construction, not a fully studentized bootstrap-t procedure.
