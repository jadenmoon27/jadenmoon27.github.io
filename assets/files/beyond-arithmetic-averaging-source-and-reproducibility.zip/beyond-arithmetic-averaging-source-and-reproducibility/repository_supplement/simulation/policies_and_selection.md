# Feature views, policy library, and holdout selection

The finite library contained four constant procedures:

- default;
- fixed procedure;
- alternative 1;
- alternative 2.

It also contained cue-based routers. A cue-`k` router selected alternative 1 when `X_k > 0` and alternative 2 otherwise; its inverse exchanged those choices.

- Restricted feature view: cue-1 router and its inverse.
- Expanded feature view: additionally cue-2 router and its inverse.

The policies did not receive synthetic-domain identity. A globally selected procedure could therefore perform well overall while deteriorating in a particular synthetic domain.

For each feature view, the selected policy maximized empirical equal-domain participant-macro gain on the 200-participant development sample. Exact ties followed a fixed policy order. The selected policy was frozen before evaluation on the independent test sample. The prespecified policy was set by the profile and was never selected from test outcomes.

No neural network or physiological prediction model was trained. This design evaluates the scoring and conclusion layer rather than the complete MAIBO model-development pipeline.
