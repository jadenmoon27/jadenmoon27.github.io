# Simulation design

## Independent samples

Each repetition used:

- 200 independent development participants;
- an independent test sample with `N` in `{60, 200, 1000}`;
- distinct pseudo-random streams for development data, test data, and bootstrap sampling.

The manuscript source states that stream seeds were derived from a recorded master seed, condition identifier, repetition index, and stream name by applying SHA-256 to canonical JSON and using the first 16 bytes as a 128-bit seed. The actual `STUDY_FREEZE.json` file and master-seed value are not present in the current project.

## Condition grid

- Main grid: `16 profiles x 3 test sizes x 2 synthetic-domain observation structures = 96 conditions`.
- Stress grid: 12 additional bounded rare-shock conditions.
- Repetitions: 200 per condition.
- Total independent development/test repetitions: 21,600.

The two observation structures were:

1. complete observation of all three synthetic domains;
2. missing completely at random (MCAR): all three domains with probability 0.40, or each of the three possible two-domain patterns with probability 0.20.

Missingness was independent of latent states, cues, gains, and opportunity counts. The design does not address informative missingness.

## Repeated observations and pairing

Each observed participant-domain cell contained 4, 8, or 16 opportunities with probabilities 0.25, 0.50, and 0.25. Participant-level action shocks were shared across that participant's domains and opportunities.

Every repetition produced restricted and expanded feature views on the same test participants. The feature views and interval procedures are paired analyses, not additional independent repetitions.

## Resampling

Each interval procedure used 999 participant-cluster bootstrap draws per repetition. A sampled participant retained all observed synthetic domains and opportunities.
