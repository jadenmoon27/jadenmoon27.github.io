# Evaluation endpoints and denominators

The operational overall tolerance was `tau = 0.10`; the synthetic-domain margin was `m = -0.25` BPM-scaled units. These values define the conclusion rule and are not clinical thresholds.

## Four headline endpoints

### Joint coverage

A repetition is covered only when all 24 analytic population values lie inside their corresponding intervals.

- Denominator: 21,600 independent repetitions.

### Any incorrect supported conclusion

A repetition is counted when at least one formal interval-supported statement is contradicted by analytic truth.

- Denominator: 21,600 independent repetitions.

### Unresolved output

An output is unresolved when the fixed rule withholds an overall directional conclusion because the interval evidence is insufficient. This is not a missing candidate estimate or missing prediction.

- Denominator: 43,200 feature-view outputs (two paired views per repetition).

### Adverse synthetic-domain detection

This endpoint is eligible when at least one true domain-specific value for the prespecified policy is strictly below the operational margin. Detection requires an interval upper bound below the margin in a truly adverse synthetic domain.

- Denominator: 8,400 eligible feature-view outputs.

## Additional registered endpoints

- False support for prespecified-policy domain non-deterioration: 12,000 eligible feature-view outputs.
- Boundary behavior around the overall tolerance and synthetic-domain margin.
- Point-screen population mismatch.
- Within-library selection regret.

The analysis retained exact binary-event numerators and denominators. Feature views are paired, and pooled conditions are heterogeneous; the reported rates are descriptive frequencies over the designed grid rather than independent-binomial operating guarantees.
