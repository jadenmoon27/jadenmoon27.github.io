# Simulation ablations and limitations

## Point-only ablation

Supplying degenerate intervals at the point estimates produced at least one incorrect supported conclusion in 7,697 of 21,600 repetitions (35.63%). This isolates the consequence of ignoring interval uncertainty under the fixed scoring setup; it does not imply that all point-estimate analyses are invalid.

## Withholding synthetic-domain intervals

Removing domain-specific intervals made the domain assessment unavailable in all 43,200 feature-view outputs and produced 0 of 8,400 interval-backed adverse-domain detections. The absence of false domain claims reflects missing inferential information, not successful calibration.

## Fixed-oracle point screen

In the profile with a true oracle-minus-fixed value of 0.105, just above the 0.10 threshold, the descriptive point screen fired in 39 of 1,200 evaluations per feature view (78/2,400 total). Every firing was a population mismatch. The screen therefore cannot be interpreted as an equivalence or saturation test.

## Within-library selection regret

Recorded population regret relative to the best admitted library member was zero across the designed grid. Ties allow different selected identities with equal population value. The grid therefore does not stress selection of population-suboptimal library members.

## Design limitations

The study uses finite-state synthetic losses, three synthetic domains, MCAR missingness, bounded participant shocks, and a declared finite policy library. It does not test PPG waveform models, informative missingness, continuous action spaces, broad policy-library misspecification, or external distribution shift. Within each repetition, bootstrap intervals condition on the development-selected policy and do not include that repetition's selection uncertainty.

The historical audit of a superseded implementation was removed from the final manuscript and public supplement because none of its replay or recovery values enters the reported results.
