# Fixed conclusion rule used in the known-truth simulation

This document preserves the exact interpretive logic behind the simulation endpoints. The main manuscript reports the continuous estimates, interval procedures, endpoint definitions, and headline rates. The thresholds below are analysis settings, not clinical thresholds.

## Interval labels

For an estimate with interval `[lower, upper]` and operational tolerance `tau = 0.10 BPM`, the simulation assigns:

- **supported positive** when `lower > tau`;
- **supported negative** when `upper < -tau`;
- **supported within tolerance** when `lower >= -tau` and `upper <= tau`;
- **unresolved** otherwise.

The within-tolerance label requires the entire interval to lie inside `[-tau, tau]`. Failure to support a positive or negative direction is not evidence of equivalence. Malformed or nonfinite intervals are treated as invalid inputs rather than favorable evidence.

## Overall conclusion hierarchy

The first satisfied rule determines the reported overall output.

1. **Oracle headroom within tolerance.** The label-informed oracle's gain relative to arithmetic averaging is supported within tolerance.
2. **Fixed-procedure proximity screen.** The tested fixed procedure and oracle both have supported positive gains; selected-policy minus oracle error is supported within tolerance; and the fixed and oracle point estimates differ by at most `tau`. The point-distance condition is descriptive, not an equivalence test.
3. **Selection value not established despite oracle headroom.** Oracle gain and selected-policy minus oracle error are supported positive, while selected-policy gain is not supported positive.
4. **Audited router and selected policy agree within tolerance.** The selected policy and audited router both have supported positive gains, and audited-router minus selected-policy error is supported within tolerance.
5. **Audited router underperforms the selected policy.** Selected-policy gain and audited-router minus selected-policy error are supported positive.
6. **Unresolved.** None of the preceding patterns is supported.

When restricted and expanded feature views are paired, an accessibility-recovery pattern is reported only when the restricted view satisfies rule 3 while the expanded view has supported positive selected-policy gain and selected-policy minus oracle error supported within tolerance. This is a descriptive paired-view pattern, not a causal effect of adding features.

## Synthetic-domain status

The operational synthetic-domain margin is `m = -0.25 BPM`.

- Non-deterioration for the audited router is supported only when every examined domain's lower interval bound exceeds `m`.
- Adverse evidence for a procedure in a domain is supported only when that domain's upper interval bound is below `m`.
- If intervals exist but neither condition holds, the domain result is unresolved.
- If a required interval is absent, the domain result is unavailable.

A point estimate at or below `m` is only a descriptive screen. Absence of an adverse point or upper-bound flag does not establish non-deterioration. The overall and domain outputs are not assumed independent.

## Relationship to the headline endpoints

- **Joint coverage** checks whether all 24 analytic population values are contained by their intervals.
- **Any incorrect supported conclusion** records whether at least one interval-backed output contradicts analytic truth.
- **Unresolved output** records whether the overall hierarchy ends at rule 6; it is not a missing HR estimate.
- **Adverse synthetic-domain detection** records whether at least one truly adverse domain is identified by the interval rule.

The simulation evaluates this fixed conclusion layer under designed losses. It does not validate MAIBO measurements, fitted HR models, physiology, or cross-device generalization.
