# Analytic population truth

Under zero-mean shocks conditional on synthetic domain, state, and cues, the population gains for constant and cue-based procedures are:

```text
E[g_F | d]             = f_d
E[g_1 | d]             = b_d
E[g_2 | d]             = b_d
E[g_router(k) | d]     = b_d + a_d (2 q_k,d - 1)
E[g_inverse(k) | d]    = b_d - a_d (2 q_k,d - 1)
```

The candidate-restricted oracle truth was computed by enumerating the joint finite support and probability-weighting:

```text
max(0, g_F, g_1, g_2)
```

This is the expectation of a pointwise maximum, not the maximum of expected gains. The calculation therefore uses the joint shock distribution, including the nonuniform probabilities of the rare-shock support.

After development selection, the selected policy's population values use the analytic expectation of that selected policy, not the best member of the library in hindsight. The analytic routine sums the joint probabilities of the participant shocks, opportunity shocks, and latent state. It uses no generated test sample or Monte Carlo approximation.

The conclusion rule received only test-sample estimates and intervals. It did not receive profile names, generating parameters, population values, selected-policy truth, or random seeds.
