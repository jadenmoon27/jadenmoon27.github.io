# Reproducibility crosswalk

This release separates five distinct reproduction levels.

| Level | Status | Evidence in this release |
|---|---|---|
| Manuscript compilation | Supported | `main.tex`, `ref.bib`, `neurips_2026.sty` |
| Display regeneration from frozen values | Supported | `tables/` and `figures/figure2/` |
| Aggregate-result inspection | Supported | `results/`, `simulation/results.md`, and the claim ledger |
| Real-data estimate and interval recalculation | Not supported | Participant-level predictions and interval scripts are absent |
| End-to-end model or simulation rerun | Not supported | Training/inference code, trained models, executable simulation code, and repetition-level records are absent |

The institutional ethics letter is not a computational input and is not part of the release. Its absence is unrelated to the unavailable training, prediction, and simulation artifacts.

See `../README.md` for the complete artifact-by-artifact inventory and `../manifests/RELEASE_INVENTORY.tsv` for a machine-readable status table.
