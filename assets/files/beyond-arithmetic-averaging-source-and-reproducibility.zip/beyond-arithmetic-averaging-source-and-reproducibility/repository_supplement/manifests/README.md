# Release manifests

- `RELEASE_INVENTORY.tsv` records availability and reproduction scope by artifact category.
- `SOURCE_TREE.txt` lists the files in `repository_supplement/`.
- `RELEASE_MANIFEST.sha256` contains SHA-256 checksums for every supplement file except the manifest itself.

A matching checksum confirms file identity, not scientific validity or independent reproducibility.
