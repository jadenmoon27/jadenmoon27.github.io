# Audited-router versus selected-policy gap accounting

**Analysis status:** Descriptive.

The audited lower-quantile router selected a nonbaseline candidate on 3,018 of 57,797 segments (5.22%). The training-selected policy did so on 16,530 segments (28.60%). These are raw segment-level switching frequencies, not equal-posture participant-macro performance estimates.

Positive contributions mean higher audited-router error. Frequencies and contributions below use the equal-posture participant-macro weights and retain every participant-posture denominator. They are not category-conditional means or raw segment percentages.

| Category | Weighted frequency | Contribution (BPM) | Nominal marginal 95% interval | Signed share |
|---|---:|---:|---:|---:|
| Same candidate | 71.54% | 0.0000 | [0.0000, 0.0000] | 0.00% |
| Missed beneficial selected-policy switch | 14.80% | +0.2009 | [0.1793, 0.2249] | 148.54% |
| Nonbeneficial selected-policy switch | 11.50% | -0.1052 | [-0.1155, -0.0957] | -77.81% |
| Harmful audited-router switch | 0.42% | +0.0216 | [-0.0008, 0.0531] | 15.99% |
| Audited-router-only nonharmful switch | 0.02% | -0.000047 | [-0.000143, -0.000000363] | -0.03% |
| Different nonbaseline candidates | 1.73% | +0.0180 | [0.0051, 0.0320] | 13.31% |
| **Total** | **100.00%** | **0.1353** | — | **100.00%** |

The missed-beneficial category was the largest positive contribution in every outer fold and posture summary. The negative contribution from nonbeneficial selected-policy switches explains why the largest positive component exceeds the signed net difference. This accounting uses frozen predictions and decisions and does not identify a causal mechanism, an optimal switching frequency, or a threshold change that would repair the audited router.
