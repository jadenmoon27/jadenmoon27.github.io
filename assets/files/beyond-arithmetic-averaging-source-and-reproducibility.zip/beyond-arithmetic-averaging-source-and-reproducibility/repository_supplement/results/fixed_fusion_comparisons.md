# Post hoc comparisons with fixed learned bilateral fusion

**Analysis status:** Post hoc secondary.

Positive estimates mean lower equal-posture participant-macro MAE for the named routing procedure or added component than for the stated comparator. The simultaneous intervals below use a single 22-coordinate family and condition on the frozen predictions, routing decisions, and selected policies.

## Routing procedures versus fixed fusion

| Comparison | Estimate (BPM) | Marginal 95% interval | Simultaneous 95% interval |
|---|---:|---:|---:|
| Linear mean-gain routing, prediction features | 0.032 | [0.003, 0.071] | [-0.038, 0.103] |
| Compact nonlinear routing, prediction features | 0.089 | [0.042, 0.158] | [0.019, 0.160] |
| Balanced-policy routing, prediction features | 0.092 | [0.045, 0.161] | [0.022, 0.163] |
| Full compatible routing, prediction features | 0.092 | [0.045, 0.161] | [0.022, 0.163] |
| Linear mean-gain routing, prediction + signal summaries | 0.037 | [0.008, 0.078] | [-0.034, 0.107] |
| Compact nonlinear routing, prediction + signal summaries | 0.121 | [0.062, 0.200] | [0.050, 0.191] |
| Balanced-policy routing, prediction + signal summaries | 0.120 | [0.061, 0.200] | [0.050, 0.191] |
| Full compatible routing, prediction + signal summaries | 0.120 | [0.061, 0.200] | [0.050, 0.191] |
| Audited lower-quantile router versus fixed fusion | -0.015 | [-0.055, 0.033] | [-0.086, 0.055] |

## Increment from adding signal-summary features

| Library | Estimate (BPM) | Marginal 95% interval | Simultaneous 95% interval |
|---|---:|---:|---:|
| Fixed-candidate library | 0.000 | [0.000, 0.000] | [0.000, 0.000] |
| Linear mean-gain library | 0.005 | [-0.004, 0.014] | [-0.066, 0.075] |
| Compact nonlinear library | 0.032 | [0.004, 0.069] | [-0.039, 0.102] |
| Balanced-policy library | 0.028 | [0.001, 0.063] | [-0.043, 0.098] |
| Full compatible library | 0.028 | [0.001, 0.063] | [-0.043, 0.098] |

## Increment from expanding the policy library

| Comparison | Estimate (BPM) | Marginal 95% interval | Simultaneous 95% interval |
|---|---:|---:|---:|
| Fixed candidates to linear, prediction features | 0.032 | [0.003, 0.071] | [-0.038, 0.103] |
| Linear to compact nonlinear, prediction features | 0.057 | [0.027, 0.094] | [-0.013, 0.127] |
| Compact nonlinear to balanced, prediction features | 0.003 | [-0.004, 0.012] | [-0.067, 0.074] |
| Balanced to full, prediction features | 0.000 | [0.000, 0.000] | [0.000, 0.000] |
| Fixed candidates to linear, prediction + signal summaries | 0.037 | [0.008, 0.078] | [-0.034, 0.107] |
| Linear to compact nonlinear, prediction + signal summaries | 0.084 | [0.045, 0.133] | [0.014, 0.155] |
| Compact nonlinear to balanced, prediction + signal summaries | -0.001 | [-0.004, 0.002] | [-0.071, 0.070] |
| Balanced to full, prediction + signal summaries | 0.000 | [0.000, 0.000] | [0.000, 0.000] |

Displayed zeros are numerical results for the frozen records and do not establish population equivalence. Adjustment within this family is not manuscript-wide error control and does not remove the post hoc status of the scientific comparisons.
