# Participant-level improvement and deterioration

**Analysis status:** Post hoc secondary.

Each participant's mean absolute error was first averaged equally across their observed postures. Percentages below use participants, not segments. The posture sets overlap. Intervals are nominal simultaneous participant-cluster 95% summaries within one 24-proportion family. The 0.5-BPM threshold is operational, not clinical.

## Training-selected policy relative to fixed fusion

| Participant set | Any observed improvement | Improvement at least 0.5 BPM | Deterioration at least 0.5 BPM | Participants |
|---|---:|---:|---:|---:|
| Overall | 57.00% [51.07, 62.93] | 3.13% [0.00, 9.06] | 1.57% [0.00, 7.50] | 1,086 |
| Lying | 54.18% [48.25, 60.11] | 3.22% [0.00, 9.15] | 2.89% [0.00, 8.83] | 622 |
| Sitting | 54.94% [49.01, 60.87] | 3.54% [0.00, 9.47] | 2.19% [0.00, 8.12] | 961 |
| Standing | 59.55% [53.62, 65.48] | 6.46% [0.53, 12.39] | 1.12% [0.00, 7.06] | 356 |

## Audited lower-quantile router relative to fixed fusion

| Participant set | Any observed improvement | Improvement at least 0.5 BPM | Deterioration at least 0.5 BPM | Participants |
|---|---:|---:|---:|---:|
| Overall | 44.11% [38.17, 50.04] | 2.76% [0.00, 8.69] | 6.45% [0.51, 12.38] | 1,086 |
| Lying | 44.53% [38.60, 50.47] | 2.57% [0.00, 8.50] | 8.36% [2.43, 14.29] | 622 |
| Sitting | 47.03% [41.10, 52.97] | 3.33% [0.00, 9.26] | 7.70% [1.77, 13.63] | 961 |
| Standing | 50.00% [44.07, 55.93] | 6.74% [0.81, 12.67] | 8.15% [2.21, 14.08] | 356 |

These values describe observed prediction-error changes under the frozen procedures. They are not treatment effects, patient benefits, clinical harms, or external population prevalences.
