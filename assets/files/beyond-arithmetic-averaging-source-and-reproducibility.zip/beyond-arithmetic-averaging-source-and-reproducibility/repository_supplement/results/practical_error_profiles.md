# Practical error profiles

**Analysis status:** Post hoc secondary.

Positive values are fixed-fusion endpoint minus policy endpoint. Medians, P90, P95, and exceedance fractions were calculated within participant-posture cells, averaged equally over participants within posture, and then averaged equally over postures. They are not pooled-segment quantiles. Mean-error contrasts inherit the 22-comparison family; the ten nonmean contrasts form a separate simultaneous family.

| Endpoint | Unit | Training-selected policy vs fixed fusion | Audited router vs fixed fusion |
|---|---|---:|---:|
| Mean absolute error | BPM | +0.120 [0.050, 0.191] | -0.015 [-0.086, 0.055] |
| Macro median absolute error | BPM | +0.138 [0.054, 0.221] | -0.002 [-0.086, 0.082] |
| Macro P90 absolute error | BPM | +0.105 [0.022, 0.189] | -0.082 [-0.165, 0.002] |
| Macro P95 absolute error | BPM | +0.047 [-0.037, 0.131] | -0.109 [-0.193, -0.025] |
| Fraction above 5 BPM | Proportion | +0.007 [-0.077, 0.091] | -0.005 [-0.089, 0.078] |
| Fraction above 10 BPM | Proportion | +0.004 [-0.080, 0.088] | +0.000 [-0.083, 0.084] |

The selected-policy P95 and exceedance intervals include zero. The audited router's macro-P95 estimate corresponds to 0.109 BPM higher macro-P95 error than fixed fusion, with interval [0.025, 0.193] for the excess-error orientation. These endpoints do not establish clinical utility, patient benefit, or safety. The 5- and 10-BPM thresholds are operational rather than clinical thresholds.
