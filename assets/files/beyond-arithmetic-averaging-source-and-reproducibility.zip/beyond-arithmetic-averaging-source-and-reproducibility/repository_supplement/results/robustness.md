# MAIBO robustness results

**Analysis status:** Primary robustness assessment associated with the audited-router versus training-selected-policy comparison.

Positive values are audited-router MAE minus training-selected-policy MAE, so positive values favor the training-selected policy. Intervals are nominal marginal participant-cluster 95% summaries with predictions and selected policies fixed. Posture intervals are not one simultaneous family.

| Analysis | Participants | Difference (BPM) | Interval or sensitivity summary |
|---|---:|---:|---|
| Primary equal-posture estimate | 1,086 | 0.135 | 95% interval [0.093, 0.187] |
| Lying participant set | 622 | 0.122 | 95% interval [0.073, 0.176] |
| Sitting participant set | 961 | 0.109 | 95% interval [0.070, 0.153] |
| Standing participant set | 356 | 0.175 | 95% interval [0.090, 0.283] |
| Three fixed prediction seeds | 1,086 | 0.145, 0.127, 0.149 | Point sensitivities; not independent replications |
| Delete-one-participant analysis | 1,085 per deletion | 0.121-0.138 | Range across 1,086 deletions; maximum absolute shift 0.0146 BPM |
| Complete-three-posture subset | 46 | Mean 0.112; median 0.053 | Secondary complete-case sensitivity; no registered interval |

The posture sets overlap and differ in composition. The complete-posture result targets the 46 participants observed in all three postures; it is not a full-cohort within-person estimate. The fixed-seed values retain the frozen routing decisions and therefore are sensitivity checks rather than independently retrained pipelines.
