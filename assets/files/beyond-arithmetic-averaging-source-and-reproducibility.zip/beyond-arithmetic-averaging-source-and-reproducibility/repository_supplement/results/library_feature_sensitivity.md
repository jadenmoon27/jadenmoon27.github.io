# Policy-library and feature sensitivity

**Analysis status:** Post hoc secondary.

All ten nested library/feature configurations had lower estimated mean absolute error than arithmetic averaging, with reductions ranging from 0.254 to 0.375 BPM. The full compatible library with prediction-derived and signal-summary features reproduced the displayed training-selected-policy result at the reported precision: 0.374 BPM reduction relative to averaging, nominal marginal 95% interval [0.295, 0.463].

## Compact nonlinear routing

| Feature set | Reduction vs arithmetic averaging (BPM; marginal 95% interval) | Reduction vs fixed fusion (BPM; simultaneous 95% interval) |
|---|---:|---:|
| Prediction-derived features | 0.343 [0.266, 0.428] | +0.089 [0.019, 0.160] |
| Prediction-derived plus signal-summary features | 0.375 [0.296, 0.463] | +0.121 [0.050, 0.191] |

Adding signal-summary features to the compact nonlinear library changed MAE by +0.032 BPM relative to the prediction-only version; the simultaneous 95% interval was [-0.039, 0.102]. The interval includes zero and does not establish either feature usefulness or feature equivalence.

The nested libraries were: fixed candidates only; fixed candidates plus linear mean-gain routing; a compact nonlinear library adding random-forest and gradient-boosted mean-gain routing; a balanced-policy library adding participant-balanced lower-quantile and equal-posture mean-gain procedures; and the full compatible library adding two audited-router ablations. Every selection used outer-training out-of-fold evidence before outer-test evaluation.

The editable sensitivity figure remains in `figures/figureD_policy_feature_sensitivity.pdf`.
