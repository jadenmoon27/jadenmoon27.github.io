# Results supplement

This directory contains detailed MAIBO secondary and robustness results moved out of the final main manuscript.

- `robustness.md`: posture, seed, delete-one-participant, and complete-posture checks for audited-router versus training-selected-policy MAE.
- `gap_accounting.md`: switching frequencies and the descriptive category decomposition of the audited-selected difference.
- `library_feature_sensitivity.md`: nested policy-library and feature-set sensitivity.
- `fixed_fusion_comparisons.md`: the complete post hoc 22-coordinate family involving fixed learned bilateral fusion, feature increments, and library increments.
- `practical_error_profiles.md`: median, P90, P95, and exceedance outcomes.
- `participant_heterogeneity.md`: participant-level observed improvement and deterioration proportions.

These records reuse the same retained MAIBO archive, supplied HR labels, frozen predictions, outer-test routing decisions, and selected policies as the main analysis. They are not independent replications. The repository files preserve analysis status and interpretation boundaries from `revision_control/CLAIM_LEDGER.md`.
