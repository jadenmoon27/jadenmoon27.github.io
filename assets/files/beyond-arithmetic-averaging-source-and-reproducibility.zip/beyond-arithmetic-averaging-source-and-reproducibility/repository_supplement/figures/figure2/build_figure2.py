from __future__ import annotations

import os
from datetime import datetime, timezone
os.environ.setdefault('SOURCE_DATE_EPOCH', '1788998400')

import json
from pathlib import Path
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

HERE = Path(__file__).resolve().parent
OUT_DIR = HERE / 'generated'
OUT_DIR.mkdir(parents=True, exist_ok=True)

data = json.loads((HERE / 'figure2_reported_data.json').read_text())
tokens = json.loads((HERE / 'figure2_visual_tokens.json').read_text())
rows = data['rows']

# Locked geometry: 225 x 159 pt.
width_pt = tokens['geometry']['width']
height_pt = tokens['geometry']['height']
figsize = (width_pt / 72.0, height_pt / 72.0)

palette = tokens['palette']
sizes = tokens['typography']['sizes_pt_at_final_insertion']
interval = tokens['interval_style']

mpl.rcParams.update({
    'font.family': tokens['typography']['font_family_primary'],
    'font.size': sizes['body_label'],
    'text.color': palette['text_primary']['hex'],
    'axes.labelcolor': palette['text_primary']['hex'],
    'axes.edgecolor': palette['text_secondary']['hex'],
    'xtick.color': palette['text_secondary']['hex'],
    'ytick.color': palette['text_secondary']['hex'],
    'figure.facecolor': palette['background']['hex'],
    'axes.facecolor': palette['background']['hex'],
    'pdf.fonttype': tokens['typography']['font_embedding']['pdf_fonttype'],
    'ps.fonttype': tokens['typography']['font_embedding']['pdf_fonttype'],
    'svg.fonttype': tokens['typography']['font_embedding']['svg_fonttype'],
    'svg.hashsalt': 'AIDHR-F2-FIGURE2-v1',
})

fig = plt.figure(figsize=figsize, dpi=144)
fig.patch.set_facecolor(palette['background']['hex'])

# Plot geometry in figure coordinates. The small negative x-range keeps zero
# visibly inside the panel without suggesting negative estimates.
ax = fig.add_axes([0.300, 0.225, 0.665, 0.630], facecolor='none')
ax.patch.set_alpha(0.0)
ax.set_xlim(-0.01, 0.30)
ax.set_ylim(-0.10, 4.05)

# Row geometry: label/value line above, interval/participant-count line below.
plot_y = [3.20, 2.20, 1.20, 0.20]
text_y = [3.70, 2.70, 1.70, 0.70]

# Highlight the Overall row across the entire canvas.
def data_y_to_fig(y: float) -> float:
    return fig.transFigure.inverted().transform(ax.transData.transform((0, y)))[1]

band_bottom = data_y_to_fig(2.96)
band_top = data_y_to_fig(3.96)
fig.add_artist(Rectangle(
    (0.018, band_bottom), 0.964, band_top - band_bottom,
    transform=fig.transFigure,
    facecolor=palette['overall_band']['hex'], edgecolor='none', zorder=-10,
))

# Quiet x-grid. Zero receives its own dashed reference treatment.
for x in [0.10, 0.20, 0.30]:
    ax.axvline(
        x,
        color=palette['grid']['hex'],
        linewidth=interval['grid']['line_width_pt'],
        zorder=0,
    )
ax.axvline(
    0.0,
    color=interval['zero_reference']['color'],
    linewidth=interval['zero_reference']['line_width_pt'],
    linestyle=(0, tuple(interval['zero_reference']['dash_pattern_pt'])),
    zorder=1,
)

# Intervals and point estimates.
for idx, (row, y) in enumerate(zip(rows, plot_y)):
    est = row['estimate_BPM']
    lo = row['interval_95_low_BPM']
    hi = row['interval_95_high_BPM']
    is_overall = idx == 0
    color = palette['selected']['hex'] if is_overall else palette['text_secondary']['hex']
    marker = 's' if is_overall else 'o'
    marker_size = interval['overall_marker_size_pt'] if is_overall else interval['marker_size_pt']

    ax.errorbar(
        est,
        y,
        xerr=[[est - lo], [hi - est]],
        fmt=marker,
        markersize=marker_size,
        markerfacecolor=color,
        markeredgecolor=color,
        markeredgewidth=interval['marker_edge_width_pt'],
        color=color,
        ecolor=color,
        elinewidth=interval['interval_line_width_pt'],
        capsize=interval['cap_length_pt'],
        capthick=interval['cap_line_width_pt'],
        zorder=3,
    )

# Remove all but the bottom axis.
for side in ('left', 'right', 'top'):
    ax.spines[side].set_visible(False)
ax.spines['bottom'].set_linewidth(0.8)
ax.spines['bottom'].set_color(palette['text_secondary']['hex'])
ax.set_yticks([])
ax.set_xticks([0.00, 0.10, 0.20, 0.30])
ax.set_xticklabels(['0.00', '0.10', '0.20', '0.30'], fontsize=sizes['tick_label'])
ax.tick_params(axis='x', length=3.0, width=0.7, pad=2.0)

# Figure-level header and divider.
fig.text(
    0.032, 0.934, 'Participant set',
    ha='left', va='center', fontsize=sizes['box_title'], fontweight='bold',
    color=palette['text_secondary']['hex'],
)
fig.text(
    0.962, 0.934, 'Estimate [95% CI]',
    ha='right', va='center', fontsize=sizes['box_title'], fontweight='bold',
    color=palette['text_secondary']['hex'],
)
fig.add_artist(plt.Line2D(
    [0.032, 0.968], [0.884, 0.884], transform=fig.transFigure,
    color=palette['rule']['hex'], linewidth=0.65,
))

# Left labels and right-aligned numeric annotations.
for idx, (row, y_name, y_plot) in enumerate(zip(rows, text_y, plot_y)):
    is_overall = idx == 0
    y_name_fig = data_y_to_fig(y_name)
    y_n_fig = data_y_to_fig(y_plot)
    label_color = palette['text_primary']['hex']
    value_color = palette['selected']['hex'] if is_overall else palette['text_secondary']['hex']

    fig.text(
        0.032, y_name_fig, row['label'],
        ha='left', va='center', fontsize=sizes['body_label'] + (0.5 if is_overall else 0.0),
        fontweight='bold' if is_overall else 'normal', color=label_color,
    )
    fig.text(
        0.032, y_n_fig, f"n = {row['participant_identifiers']:,}",
        ha='left', va='center', fontsize=sizes['tick_label'],
        color=palette['text_secondary']['hex'],
    )
    fig.text(
        0.962, y_name_fig,
        f"{row['estimate_BPM']:.3f} [{row['interval_95_low_BPM']:.3f}, {row['interval_95_high_BPM']:.3f}]",
        ha='right', va='center', fontsize=sizes['value_label'],
        fontweight='bold' if is_overall else 'normal', color=value_color,
    )

# Locked axis title and directional subtitle.
fig.text(
    0.632, 0.105, 'Audited-router minus selected-policy MAE (BPM)',
    ha='center', va='center', fontsize=sizes['subtitle_or_status'],
    color=palette['text_primary']['hex'],
)
fig.text(
    0.632, 0.041, 'Positive values favor the selected policy.',
    ha='center', va='center', fontsize=sizes['subtitle_or_status'],
    color=palette['text_secondary']['hex'],
)

pdf_path = OUT_DIR / 'figure_maibo_audited_vs_selected.pdf'
svg_path = OUT_DIR / 'figure2_audited_vs_selected_editable.svg'
png_path = OUT_DIR / 'figure_maibo_audited_vs_selected_render.png'

fixed_dt = datetime(2026, 9, 10, tzinfo=timezone.utc)
fig.savefig(pdf_path, format='pdf', metadata={
    'Title': 'Figure 1: Audited router versus training-selected policy overall and by posture',
    'Subject': 'Audited-router MAE minus training-selected-policy MAE with marginal participant-cluster 95% intervals',
    'Author': 'Jaden Moon, Yu Yvonne Wu, Andrew T. Campbell',
    'Keywords': 'MAIBO, audited router, training-selected policy, participant-cluster interval',
    'CreationDate': fixed_dt,
    'ModDate': fixed_dt,
})
fig.savefig(svg_path, format='svg', metadata={
    'Title': 'Figure 1: Audited router versus training-selected policy overall and by posture',
    'Description': 'Audited-router MAE minus training-selected-policy MAE with marginal participant-cluster 95% intervals',
    'Creator': 'AID-HR figure renderer',
    'Date': '2026-09-10',
})
fig.savefig(png_path, format='png', dpi=300)
plt.close(fig)

print(pdf_path)
print(svg_path)
print(png_path)
