# Figure 1 regeneration

Contents:

- `build_figure2.py` — deterministic display renderer;
- `figure2_reported_data.json` — frozen reported values and participant counts;
- `figure2_visual_tokens.json` — locked geometry and typography settings;
- `figure_maibo_audited_vs_selected.pdf` — approved manuscript PDF asset;
- `figure2_audited_vs_selected_editable.svg` — approved editable vector asset.

Run `python build_figure2.py` from this directory. Generated validation files are written to `generated/`.

The renderer supports display regeneration only. It does not recompute the point estimates, bootstrap intervals, participant counts, or policy outputs.

The directory name `figure2/` is retained as a historical provenance path; the visible zero-appendix manuscript numbers this plot as Figure 1.
