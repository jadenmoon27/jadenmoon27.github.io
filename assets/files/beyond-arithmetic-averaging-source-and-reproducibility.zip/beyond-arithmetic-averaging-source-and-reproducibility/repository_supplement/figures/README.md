# Figure display sources

## Figure 1

`figure2/` contains a self-contained renderer, frozen reported values, visual tokens, and approved PDF/SVG outputs for the audited-router versus training-selected-policy plot.

Running:

```bash
python figure2/build_figure2.py
```

writes validation outputs to `figure2/generated/`. The script redraws the reported point estimates and intervals. It does not fit models, load participant-level predictions, or recalculate uncertainty intervals.

## Workflow figure (not included)

The development-prediction-audit diagram remains deferred and is not included as a final release artifact. Legacy Figure 1 files elsewhere in the working project are historical revision materials and must not be described as the final preprint figure.
