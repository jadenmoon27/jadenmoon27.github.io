# Beyond Arithmetic Averaging

**Beyond Arithmetic Averaging: Comparator-Aware Evaluation of Adaptive Routing for Wearable Heart-Rate Estimation**

Jaden Moon, Yu Yvonne Wu, and Andrew T. Campbell

**Preprint, November 2026. Not peer reviewed.**

This package accompanies the public preprint. It supports manuscript compilation, inspection of the declared methods and secondary analyses, regeneration of the three main tables from frozen reported values, and regeneration of Figure 1 from frozen reported values.

## Contents

- `main.tex`, `ref.bib`, `neurips_2026.sty` — manuscript source and bibliography.
- `drafts/tables/table1_population_structure.tex` — source included by `main.tex`.
- `stage3_assets/figures/figure_maibo_audited_vs_selected.pdf` — figure included by `main.tex`.
- `repository_supplement/methods/` — data handling, candidate estimators, routing, policy selection, and participant-disjoint evaluation documentation.
- `repository_supplement/results/` — secondary and robustness result records.
- `repository_supplement/simulation/` — known-truth simulation specification and reported aggregate outcomes.
- `repository_supplement/tables/` — LaTeX sources for the three main tables.
- `repository_supplement/figures/` — Figure 1 renderer and frozen display inputs.
- `repository_supplement/manifests/` — release inventory and integrity records.

## Build the manuscript

From this directory:

```bash
pdflatex main.tex
bibtex8 main
pdflatex main.tex
pdflatex main.tex
```

## Reproducibility boundary

This release does **not** include the original MAIBO preprocessing, training, or inference implementation; trained model states; participant-level candidate predictions; reference-heart-rate arrays; executable simulation code; or repetition-level simulation records. It therefore does not support end-to-end retraining or independent recomputation of the reported real-data intervals or simulation rates.

The public MAIBO Version V1 dataset is available from Zenodo at DOI `10.5281/zenodo.19440421` and is not redistributed here.

## Version and licensing

This website release corresponds to manuscript version 0.17. No explicit reuse license is included in this package. Add a public license only after all authors approve it.
